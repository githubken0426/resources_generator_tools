package com.gtercn.wowonderful.weixin.cms.service;

import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class WeixinConfigListener implements ServletContextListener {

	private WeixinConfigUpdating weixinConfigUpdating;
	private ApplicationContext app;

	public void contextInitialized(ServletContextEvent arg0) {
		try {
			System.out.println("WeixinConfigListener has been init... ");

			app = WebApplicationContextUtils.getWebApplicationContext(arg0
					.getServletContext());

			TimerTask task = new ConfigUpdater();
			Timer timer = new Timer();

			// 5400秒更新(90分钟)
			timer.schedule(task, 0, 90 * 60 * 1000);
			// 20秒更新(测试用)
			// timer.schedule(task, 0, 20 * 1000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {

	}

	class ConfigUpdater extends TimerTask {
		@Override
		public void run() {
			weixinConfigUpdating = (WeixinConfigUpdating) app
					.getBean("weixinConfigUpdating");
			weixinConfigUpdating.updateCommonConfig();
		}
	}

}
