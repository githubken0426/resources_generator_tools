package com.gtercn.wowonderful.cms.entity;

public class WeixinConfig extends WeixinConfigLog {
	
}
