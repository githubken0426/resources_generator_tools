package com.gtercn.wowonderful.weixin.cms.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gtercn.wowonderful.cms.entity.WeixinConfig;
import com.gtercn.wowonderful.cms.entity.WeixinConfigLog;
import com.gtercn.wowonderful.cms.service.WeixinConfigLogService;
import com.gtercn.wowonderful.cms.service.WeixinConfigService;
import com.gtercn.wowonderful.cms.util.CommonUtil;

@Service(value = "weixinConfigUpdating")
public class WeixinConfigUpdating {

	@Autowired
	private WeixinConfigService weixinConfigService;
	@Autowired
	private WeixinConfigLogService weixinConfigLogService;

	/**
	 * 统一更新微信配置表中信息(最多十五个微信公众号)
	 */
	public void updateCommonConfig() {
		try {
			Map<String, Object> map = new HashMap<String, Object>();

			map.put("beginResult", 0);
			map.put("pageSize", 15);

			// 检索微信公众号信息
			List<WeixinConfig> list = weixinConfigService.queryAllData(map);
			for (WeixinConfig bean : list) {
				updateOne(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 更新微信公众号（一个）
	 * 
	 * @param bean
	 */
	private void updateOne(WeixinConfig bean) {
		try {
			// 获取 access_token
			String access_token = getAccessToken(bean);

			// 更新配置表中access_token
			bean.setAccessToken(access_token);
			bean.setModifyid("SYS");
			int ret1 = weixinConfigService.updateData(bean);

			// 插入log
			String uuid = CommonUtil.getUID();
			bean.setId(uuid);
			bean.setCreateid("SYS");
			bean.setModifyid("SYS");

			int ret2 = weixinConfigLogService.addData((WeixinConfigLog) bean);

			String str = "ConfigId = " + bean.getConfigid() + " ";
			if (ret1 == 1 && ret2 == 1) {
				str = str + "更新成功！";
				System.out.println(str);
			} else {
				str = str + "更新失败！";
				System.out.println(str);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 通过微信接口获取access_token
	 * 
	 * @param bean
	 * @return
	 */
	private String getAccessToken(WeixinConfig bean) {
		String access_token = "ERROR";
		String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid="
				+ bean.getAppid() + "&secret=" + bean.getAppsecret();

		try {

			HttpUtil util = new HttpUtil();
			String json = util.executeGet(url);

			// 解析json
			JSONObject obj = JSONObject.fromObject(json);
			if (obj.has("access_token")) {
				access_token = obj.getString("access_token");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return access_token;
	}
}
