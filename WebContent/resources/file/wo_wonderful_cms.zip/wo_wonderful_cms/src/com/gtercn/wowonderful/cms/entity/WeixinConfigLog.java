package com.gtercn.wowonderful.cms.entity;

import java.util.Date;

public class WeixinConfigLog {
    private String id;

    private String configid;

    private String orgid;

    private String serviceid;

    private String originalid;

    private String appid;

    private String appsecret;

    private String token;

    private String encodingMode;

    private String encodingAeskey;

    private String accessToken;

    private Date accessTokenTime;

    private String accessJsTicket;

    private Date accessJsTicketTime;

    private String createid;

    private Date createDate;

    private String modifyid;

    private Date modifyDate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getConfigid() {
        return configid;
    }

    public void setConfigid(String configid) {
        this.configid = configid == null ? null : configid.trim();
    }

    public String getOrgid() {
        return orgid;
    }

    public void setOrgid(String orgid) {
        this.orgid = orgid == null ? null : orgid.trim();
    }

    public String getServiceid() {
        return serviceid;
    }

    public void setServiceid(String serviceid) {
        this.serviceid = serviceid == null ? null : serviceid.trim();
    }

    public String getOriginalid() {
        return originalid;
    }

    public void setOriginalid(String originalid) {
        this.originalid = originalid == null ? null : originalid.trim();
    }

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid == null ? null : appid.trim();
    }

    public String getAppsecret() {
        return appsecret;
    }

    public void setAppsecret(String appsecret) {
        this.appsecret = appsecret == null ? null : appsecret.trim();
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token == null ? null : token.trim();
    }

    public String getEncodingMode() {
        return encodingMode;
    }

    public void setEncodingMode(String encodingMode) {
        this.encodingMode = encodingMode == null ? null : encodingMode.trim();
    }

    public String getEncodingAeskey() {
        return encodingAeskey;
    }

    public void setEncodingAeskey(String encodingAeskey) {
        this.encodingAeskey = encodingAeskey == null ? null : encodingAeskey.trim();
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken == null ? null : accessToken.trim();
    }

    public Date getAccessTokenTime() {
        return accessTokenTime;
    }

    public void setAccessTokenTime(Date accessTokenTime) {
        this.accessTokenTime = accessTokenTime;
    }

    public String getAccessJsTicket() {
        return accessJsTicket;
    }

    public void setAccessJsTicket(String accessJsTicket) {
        this.accessJsTicket = accessJsTicket == null ? null : accessJsTicket.trim();
    }

    public Date getAccessJsTicketTime() {
        return accessJsTicketTime;
    }

    public void setAccessJsTicketTime(Date accessJsTicketTime) {
        this.accessJsTicketTime = accessJsTicketTime;
    }

    public String getCreateid() {
        return createid;
    }

    public void setCreateid(String createid) {
        this.createid = createid == null ? null : createid.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getModifyid() {
        return modifyid;
    }

    public void setModifyid(String modifyid) {
        this.modifyid = modifyid == null ? null : modifyid.trim();
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }
}
