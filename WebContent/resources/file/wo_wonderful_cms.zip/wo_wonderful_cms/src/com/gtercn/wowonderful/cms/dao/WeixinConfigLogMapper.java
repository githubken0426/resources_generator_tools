package com.gtercn.wowonderful.cms.dao;

import com.gtercn.wowonderful.cms.entity.WeixinConfigLog;



import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public interface WeixinConfigLogMapper {
    int deleteByPrimaryKey(String id);

    int insert(WeixinConfigLog record);

    int insertSelective(WeixinConfigLog record);

    WeixinConfigLog selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(WeixinConfigLog record);

    int updateByPrimaryKey(WeixinConfigLog record);




	// SrcGen 添加的方法

	// 查询
	public List<WeixinConfigLog> queryAllData(Map<String, Object> map);

	// 统计数据总数（查询用）
	public int getTotalCount(Map<String, Object> map);

}