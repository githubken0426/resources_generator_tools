package com.gtercn.wowonderful.cms.service;

import java.util.List;
import java.util.Map;

import com.gtercn.wowonderful.cms.entity.WeixinConfigLog;

public interface WeixinConfigLogService {

	/**
	 * 查询
	 * 
	 * @return
	 */
	public List<WeixinConfigLog> queryAllData(Map<String, Object> map);

	/**
	 * 查询所有数据条数
	 * 
	 * @return
	 */
	public int getTotalCount(Map<String, Object> map);

	/**
	 * 根据id获取
	 * 
	 * @param id
	 * @return
	 */
	public WeixinConfigLog getDataById(String id) throws Exception;

	/**
	 * 新增
	 * 
	 * @param o
	 * @return
	 */
	public int addData(WeixinConfigLog o) throws Exception;

	/**
	 * 修改
	 * 
	 * @param o
	 * @return
	 */
	public int updateData(WeixinConfigLog o) throws Exception;

	/**
	 * 删除
	 * 
	 * @param o
	 * @return
	 */
	public int deleteData(String id) throws Exception;
	
}
