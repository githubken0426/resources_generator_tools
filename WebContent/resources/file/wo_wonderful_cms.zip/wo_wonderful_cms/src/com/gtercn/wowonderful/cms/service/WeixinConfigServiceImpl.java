package com.gtercn.wowonderful.cms.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gtercn.wowonderful.cms.dao.WeixinConfigMapper;
import com.gtercn.wowonderful.cms.entity.WeixinConfig;

@Service(value = "weixinConfigService")
public class WeixinConfigServiceImpl implements WeixinConfigService {
	@Autowired
	private WeixinConfigMapper dao;

	@Override
	public List<WeixinConfig> queryAllData(Map<String, Object> map) {
		return dao.queryAllData(map);
	}

	@Override
	public WeixinConfig getDataById(String id) throws Exception {
		return dao.selectByPrimaryKey(id);
	}

	@Override
	public int updateData(WeixinConfig o) throws Exception {
		return dao.updateByPrimaryKeySelective(o);
	}

	@Override
	public int getTotalCount(Map<String, Object> map) {
		return dao.getTotalCount(map);
	}

	@Override
	public int addData(WeixinConfig o) throws Exception {
		return dao.insert(o);		
	}

	@Override
	public int deleteData(String id) throws Exception {
		return dao.deleteByPrimaryKey(id);
	}
	
	/**
	 * 根据configid获取WeixinConfig
	 * 
	 * @param o
	 * @return
	 */
	public WeixinConfig getWeixinConfig(String configid) throws Exception {
		return dao.selectByConfigid(configid);
	}

}
