package com.gtercn.wowonderful.cms.dao;

import com.gtercn.wowonderful.cms.entity.WeixinConfig;



import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public interface WeixinConfigMapper {
    int deleteByPrimaryKey(String id);

    int insert(WeixinConfig record);

    int insertSelective(WeixinConfig record);

    WeixinConfig selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(WeixinConfig record);

    int updateByPrimaryKey(WeixinConfig record);




	// SrcGen 添加的方法

	// 查询
	public List<WeixinConfig> queryAllData(Map<String, Object> map);

	// 统计数据总数（查询用）
	public int getTotalCount(Map<String, Object> map);

	// 手工添加方法
	public WeixinConfig selectByConfigid(String configid);
	
}