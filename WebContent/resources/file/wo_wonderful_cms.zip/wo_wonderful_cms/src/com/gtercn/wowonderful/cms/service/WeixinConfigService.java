package com.gtercn.wowonderful.cms.service;

import java.util.List;
import java.util.Map;

import com.gtercn.wowonderful.cms.entity.WeixinConfig;

public interface WeixinConfigService {

	/**
	 * 查询
	 * 
	 * @return
	 */
	public List<WeixinConfig> queryAllData(Map<String, Object> map);

	/**
	 * 查询所有数据条数
	 * 
	 * @return
	 */
	public int getTotalCount(Map<String, Object> map);

	/**
	 * 根据id获取
	 * 
	 * @param id
	 * @return
	 */
	public WeixinConfig getDataById(String id) throws Exception;

	/**
	 * 新增
	 * 
	 * @param o
	 * @return
	 */
	public int addData(WeixinConfig o) throws Exception;

	/**
	 * 修改
	 * 
	 * @param o
	 * @return
	 */
	public int updateData(WeixinConfig o) throws Exception;

	/**
	 * 删除
	 * 
	 * @param o
	 * @return
	 */
	public int deleteData(String id) throws Exception;
	
	/**
	 * 根据configid获取WeixinConfig
	 * 
	 * @param o
	 * @return
	 */
	public WeixinConfig getWeixinConfig(String configid) throws Exception;	
	
}
