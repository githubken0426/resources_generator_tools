package com.gtercn.wowonderful.cms.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gtercn.wowonderful.cms.dao.WeixinConfigLogMapper;
import com.gtercn.wowonderful.cms.entity.WeixinConfigLog;

@Service(value = "weixinConfigLogService")
public class WeixinConfigLogServiceImpl implements WeixinConfigLogService {
	@Autowired
	private WeixinConfigLogMapper dao;

	@Override
	public List<WeixinConfigLog> queryAllData(Map<String, Object> map) {
		return dao.queryAllData(map);
	}

	@Override
	public WeixinConfigLog getDataById(String id) throws Exception {
		return dao.selectByPrimaryKey(id);
	}

	@Override
	public int updateData(WeixinConfigLog o) throws Exception {
		return dao.updateByPrimaryKeySelective(o);
	}

	@Override
	public int getTotalCount(Map<String, Object> map) {
		return dao.getTotalCount(map);
	}

	@Override
	public int addData(WeixinConfigLog o) throws Exception {
		return dao.insert(o);		
	}

	@Override
	public int deleteData(String id) throws Exception {
		return dao.deleteByPrimaryKey(id);
	}

}
